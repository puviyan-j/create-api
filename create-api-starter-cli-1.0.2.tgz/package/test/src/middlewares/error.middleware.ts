
    function ErrorHandler(err:any,_req:Request,res: Response,next:nextfunction) {
      let statusCode = err.status || 500;
      let message = err.message || "Internal Server Error"

    res.status(statusCode).json({
        success: false,
        statusCode,
        message,
        data: err.data ?? null,
        stack: err.data || err.stack || err,})
    }

    export {ErrorHandler}
        
    