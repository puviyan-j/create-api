

    export const findAll = async () => {
        return [];
    };

    export const findById = async (id) => {
        return {};
    };

    export const create = async (data) => {
        return {};
    };

    export const update = async (id, data) => {
        return {}
    };

    export const remove = async (id) => {
        return {};
    };