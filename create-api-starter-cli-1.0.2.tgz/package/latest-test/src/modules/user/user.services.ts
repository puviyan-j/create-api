
    
    import * as userRepository from './user.repository.js';

    export const getUsers = async () => {
        return await userRepository.findAll();
    };

    export const getUserById = async (id) => {
        return await userRepository.findById(id);
    };

    export const createUser = async (data) => {
        return await userRepository.create(data);
    };

    export const updateUser = async (id, data) => {
        return await userRepository.update(id, data);
    };

    export const deleteUser = async (id) => {
        return await userRepository.remove(id);
    };