
    import pino ,{ type Logger as pinoLogger }  from 'pino'

    
  export interface ILogger {
  info(message: string, meta?: Record<string, any>): void;
  warn(message: string, meta?: Record<string, any>): void;
  error(message: string, meta?: Record<string, any>): void;
  debug(message: string, meta?: Record<string, any>): void;
 }

    const isDev = process.env.NODE_ENV !== 'production'
    
    class Logger implements ILogger {

    private logger: pinoLogger;
     constructor() {
         this.logger = pino({
        level: process.env.LOG_LEVEL || "info",
        ...(isDev && {
            transport: {
                target: "pino-pretty",
                options: {
                    colorize: true,
                },
            }
        })
    })
        };

  info(message :string, meta = {}) {
    this.logger.info(meta, message)
  }
  warn(message :string, meta = {}) {
    this.logger.info(meta, message)
  }
  error(message :string, meta = {}) {
    this.logger.info(meta, message)
  }
  debug(message :string, meta = {}) {
     this.logger.info(meta, message)
  }
}
const logger = new Logger();

 export {logger}