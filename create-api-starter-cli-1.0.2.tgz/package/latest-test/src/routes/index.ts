
    import {Router,type Request ,type Response } from 'express';

    const router = Router();

    import  userRoutes from '../modules/user/user.routes.js'

    router.get("/health",(req:Request,res:Response)=>{res.json('Api working')});

    router.use('/users',userRoutes)

    export default router 