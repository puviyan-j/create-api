
    import express from 'express';
    import cors from 'cors';
    const app = express();
    import Router from './routes/index.js';
    import {ErrorHandler} from './middlewares/error.middleware.js';
    app.use(cors());
    app.use('/v1',Router);
    app.use(ErrorHandler)
    
    export default app